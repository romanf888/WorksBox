===================================================================
   EXTENSION GOOGLE CHROME WORKSBOX - GUIDE D'INSTALLATION (BETA)
===================================================================

Cette extension officielle vous permet de consulter les derniers cours
publiés sur WorksBox et d'y accéder en un seul clic !

Procédure d'installation dans Google Chrome :
1. Décompressez ce fichier ZIP dans un dossier sur votre ordinateur.
2. Ouvrez Google Chrome et accédez à : chrome://extensions/
3. Activez le "Mode développeur" (interrupteur en haut à droite).
4. Cliquez sur le bouton "Charger l'extension non empaquetée".
5. Sélectionnez le dossier décompressé (qui contient manifest.json, popup.html, etc.).
6. L'icône WorksBox est désormais épinglée dans votre barre d'outils !
